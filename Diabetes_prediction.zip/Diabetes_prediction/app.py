import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, roc_auc_score

# -------------------------------------------------
# Page configuration
# -------------------------------------------------
st.set_page_config(
    page_title="Diabetes Prediction",
    page_icon="🩺",
    layout="wide"
)

st.title("🩺 Diabetes Prediction App")
st.write("Machine Learning application using Logistic Regression and the diabetes.csv dataset.")

# -------------------------------------------------
# Load and train model
# -------------------------------------------------
@st.cache_resource
def train_model():
    df = pd.read_csv("diabetes.csv")

    X = df.drop("Outcome", axis=1)
    y = df["Outcome"]

    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=0.20,
        random_state=42,
        stratify=y
    )

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    model = LogisticRegression(random_state=42)
    model.fit(X_train_scaled, y_train)

    y_pred = model.predict(X_test_scaled)
    y_prob = model.predict_proba(X_test_scaled)[:, 1]

    accuracy = accuracy_score(y_test, y_pred)
    auc = roc_auc_score(y_test, y_prob)
    cm = confusion_matrix(y_test, y_pred)

    return df, model, scaler, accuracy, auc, cm


try:
    df, model, scaler, accuracy, auc, cm = train_model()
except FileNotFoundError:
    st.error("❌ diabetes.csv was not found.")
    st.info("Place diabetes.csv in the same folder as app.py and run the app again.")
    st.stop()

# -------------------------------------------------
# Sidebar
# -------------------------------------------------
st.sidebar.header("About the Dataset")
st.sidebar.write(f"Rows: {df.shape[0]}")
st.sidebar.write(f"Features: {df.shape[1] - 1}")
st.sidebar.write("Target: Outcome")

st.sidebar.markdown("---")
st.sidebar.write("0 = No Diabetes")
st.sidebar.write("1 = Diabetes")

# -------------------------------------------------
# Dataset overview
# -------------------------------------------------
tab1, tab2, tab3 = st.tabs(["🔮 Prediction", "📊 Dataset", "📈 Model Performance"])

with tab1:
    st.subheader("Enter Patient Information")

    col1, col2 = st.columns(2)

    with col1:
        pregnancies = st.number_input(
            "Pregnancies",
            min_value=0,
            max_value=20,
            value=1,
            step=1
        )

        glucose = st.number_input(
            "Glucose",
            min_value=0.0,
            max_value=300.0,
            value=120.0,
            step=1.0
        )

        blood_pressure = st.number_input(
            "Blood Pressure",
            min_value=0.0,
            max_value=200.0,
            value=70.0,
            step=1.0
        )

        skin_thickness = st.number_input(
            "Skin Thickness",
            min_value=0.0,
            max_value=100.0,
            value=20.0,
            step=1.0
        )

    with col2:
        insulin = st.number_input(
            "Insulin",
            min_value=0.0,
            max_value=900.0,
            value=80.0,
            step=1.0
        )

        bmi = st.number_input(
            "BMI",
            min_value=0.0,
            max_value=80.0,
            value=25.0,
            step=0.1
        )

        diabetes_pedigree = st.number_input(
            "Diabetes Pedigree Function",
            min_value=0.0,
            max_value=3.0,
            value=0.5,
            step=0.001
        )

        age = st.number_input(
            "Age",
            min_value=1,
            max_value=120,
            value=30,
            step=1
        )

    patient = np.array([[
        pregnancies,
        glucose,
        blood_pressure,
        skin_thickness,
        insulin,
        bmi,
        diabetes_pedigree,
        age
    ]])

    st.markdown("---")

    if st.button("🔍 Predict Diabetes", type="primary", use_container_width=True):
        patient_scaled = scaler.transform(patient)

        prediction = model.predict(patient_scaled)[0]
        probability = model.predict_proba(patient_scaled)[0][1]

        if prediction == 1:
            st.error("⚠️ Prediction: Likely to have diabetes")
        else:
            st.success("✅ Prediction: Unlikely to have diabetes")

        col1, col2 = st.columns(2)

        with col1:
            st.metric(
                "Diabetes Probability",
                f"{probability * 100:.2f}%"
            )

        with col2:
            st.metric(
                "Model Accuracy",
                f"{accuracy * 100:.2f}%"
            )

        st.caption(
            "This prediction is for educational purposes only and is not a medical diagnosis."
        )

with tab2:
    st.subheader("Dataset Preview")
    st.dataframe(df.head(10), use_container_width=True)

    st.subheader("Dataset Statistics")
    st.dataframe(df.describe(), use_container_width=True)

    col1, col2 = st.columns(2)

    with col1:
        st.subheader("Outcome Distribution")
        fig, ax = plt.subplots(figsize=(6, 4))
        sns.countplot(x="Outcome", data=df, ax=ax)
        ax.set_xlabel("Outcome (0 = No Diabetes, 1 = Diabetes)")
        ax.set_ylabel("Count")
        st.pyplot(fig)
        plt.close(fig)

    with col2:
        st.subheader("Correlation Heatmap")
        fig, ax = plt.subplots(figsize=(7, 5))
        sns.heatmap(df.corr(), annot=True, fmt=".2f", cmap="coolwarm", ax=ax)
        st.pyplot(fig)
        plt.close(fig)

with tab3:
    st.subheader("Model Performance")

    col1, col2 = st.columns(2)

    with col1:
        st.metric("Accuracy", f"{accuracy * 100:.2f}%")

    with col2:
        st.metric("ROC-AUC", f"{auc:.3f}")

    st.subheader("Confusion Matrix")

    fig, ax = plt.subplots(figsize=(6, 5))
    sns.heatmap(
        cm,
        annot=True,
        fmt="d",
        cmap="Blues",
        xticklabels=["No Diabetes", "Diabetes"],
        yticklabels=["No Diabetes", "Diabetes"],
        ax=ax
    )
    ax.set_xlabel("Predicted")
    ax.set_ylabel("Actual")
    st.pyplot(fig)
    plt.close(fig)

    st.info(
        "The model is trained automatically from diabetes.csv when the Streamlit app starts."
    )
